.. cmake-module:: ../../Modules/UseJavaClassFilelist.cmake
