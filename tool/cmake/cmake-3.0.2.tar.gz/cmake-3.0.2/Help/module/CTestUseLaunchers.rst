.. cmake-module:: ../../Modules/CTestUseLaunchers.cmake
