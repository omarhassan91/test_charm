.. cmake-module:: ../../Modules/CTest.cmake
