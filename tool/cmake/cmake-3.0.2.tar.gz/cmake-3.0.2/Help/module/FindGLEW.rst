.. cmake-module:: ../../Modules/FindGLEW.cmake
